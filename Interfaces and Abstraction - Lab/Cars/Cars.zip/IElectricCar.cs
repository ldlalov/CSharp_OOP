﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars
{
    public interface IElectricCar
    {
        public int Battery { get; set; }
    }
}
