﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public interface IDrawable
    {
        public void Draw();
        //public void WriteLine(string text);
        //public void Write(string text);
        //public void WriteAtPossition(int row,int column,string text);
    }
}
