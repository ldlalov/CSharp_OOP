﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public void StealFieldInfo(object nameOfTheClass)
        {
            StringBuilder sb = new StringBuilder();
            FieldInfo[] fields = nameOfTheClass.GetType().GetFields();
            PropertyInfo[] properties = nameOfTheClass.GetType().GetProperties();
            sb.AppendLine($"Class under investigation: {nameOfTheClass.GetType()}");
            foreach (var field in fields)
            {
                sb.AppendLine($"{field.Name} = {field.GetValue(nameOfTheClass)}");

            }

            foreach (var prop in properties)
            {
                if (prop.Name == "Password")
                {
                sb.AppendLine($"password = {prop.GetValue(nameOfTheClass)}");
                }
            }
            Console.WriteLine(sb.ToString());

            //Console.WriteLine($"Class under investigation: {nameOfTheClass}");
        }
    }
}
