﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    internal class BladeKnight : DarkKnight
    {
        public BladeKnight(string username, int level) : base(username, level)
        {
        }
    }
}
