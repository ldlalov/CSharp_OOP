﻿using System.Runtime.CompilerServices;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //Coffee cof = new Coffee("Moka", 5.20m, 150);
        }
    }
}