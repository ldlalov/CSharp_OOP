﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo
{
    internal class Mammal : Animal
    {
    }
}
