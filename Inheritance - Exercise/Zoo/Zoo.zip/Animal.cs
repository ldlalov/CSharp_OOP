﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo
{
    internal class Animal
    {
        private string name;
        public string Name { get { return name; } }
    }
}
