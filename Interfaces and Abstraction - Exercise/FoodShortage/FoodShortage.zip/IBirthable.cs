﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    internal interface IBirthable
    {
        string Birthdate { get; }
    }
}
