﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace ValidationAttributes
{
    public static class Validator
    {
        public static bool IsValid(object obj)
        {
            Type type = obj.GetType();
            PropertyInfo[] properties = type.GetProperties();
            foreach (var property in properties)
            {
                if (property.GetValue(obj) == null)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
